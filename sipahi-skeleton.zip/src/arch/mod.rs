// Katman 0: Donanım Soyutlama — Arch
// RISC-V 64-bit, CVA6, M/S/U Mode
// Sprint 1-2'de implemente edilecek
//
// Assembly stratejisi: global_asm!(include_str!(...))
// cc crate DEĞİL — 130 satır için overkill.
// include_str! yolu dosyanın BULUNDUĞU konuma göre çözümlenir:
// src/arch/mod.rs içindeyiz → "boot.S" = src/arch/boot.S
//
// Sprint 1: global_asm!(include_str!("boot.S"));
// Sprint 2: global_asm!(include_str!("trap.S"));
// Sprint 4: global_asm!(include_str!("context.S"));

// pub mod csr;    // Sprint 2
// pub mod uart;   // Sprint 1

// ═══════════════════════════════════════════════════════════
// Sprint 1 — boot.S yazarken DİKKAT:
//
// 1. mhartid kontrolü: hart 0 dışındakiler park edilmeli
//    csrr a0, mhartid → bnez a0, .park → wfi döngüsü
//
// 2. BSS sıfırlama: __bss_start → __bss_end arası
//    Bare metal'de otomatik sıfırlanmaz!
//
// 3. a0/a1 korunmalı: QEMU ZSBL a0=hartid, a1=DTB adresi
//    Stack kurulumundan ÖNCE a0/a1 clobber etme
// ═══════════════════════════════════════════════════════════
