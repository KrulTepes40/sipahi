// Sipahi — Safety-Critical Hard Real-Time Microkernel
// RISC-V 64-bit · Rust · no_std · no_alloc
//
// Doktrin: %100 deterministic · sıfır heap · sıfır panic
//          sıfır float · sıfır recursion · bounded loops

#![no_std]
#![no_main]

mod arch;
mod common;
// mod hal;       // Sprint 1'de açılacak
// mod kernel;    // Sprint 3'te açılacak
// mod ipc;       // Sprint 8'de açılacak
// mod sandbox;   // Sprint 12'de açılacak
// extern crate alloc;  // Sprint 12'de açılacak (Wasmi + static-alloc)

use core::panic::PanicInfo;

// Sprint 1'de boot.S buraya atlayacak:
// #[no_mangle]
// pub extern "C" fn rust_main() -> ! {
//     // UART başlat, "Sipahi" yazdır
//     loop {}
// }

/// Panic handler — Sipahi'de panic OLMAMALI.
/// Olursa: blackbox'a yaz, SHUTDOWN.
/// Kani bu fonksiyonun çağrılmayacağını kanıtlayacak.
#[panic_handler]
fn panic(_info: &PanicInfo) -> ! {
    // TODO Sprint 11: blackbox'a son log yaz
    // TODO: UART'a hata mesajı yaz (debug modda)
    loop {}
}
