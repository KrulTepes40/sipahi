// Sipahi — Hata türleri
// Her hata açık, her hata yakalanabilir.
// unwrap() YASAK — match veya if let kullan.

/// Sipahi kernel hata türleri
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SipahiError {
    /// Capability token doğrulaması başarısız
    CapabilityDenied,
    /// IPC buffer dolu — mesaj YAZILMADI (kayıp yok)
    BufferFull,
    /// Geçersiz syscall numarası
    InvalidSyscall,
    /// Task budget tükendi
    BudgetExhausted,
    /// CRC32 doğrulaması başarısız (IPC veya blackbox)
    IntegrityError,
    /// WASM fuel tükendi
    FuelExhausted,
    /// WASM modül imza doğrulaması başarısız
    ModuleRejected,
    /// PMP integrity check başarısız — KRİTİK
    PmpViolation,
    /// Deadline miss
    DeadlineMiss,
    /// Watchdog timeout — 3 kademeli escalation
    WatchdogTimeout,
}
