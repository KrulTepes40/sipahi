// Katman 0: HAL — Donanım Soyutlama Katmanı
// PMP, CLINT, device trait, secure boot
// Sprint 1,3,5,13'te implemente edilecek

// pub mod pmp;          // Sprint 5
// pub mod clint;        // Sprint 3
// pub mod device;       // Sprint 6
// pub mod boot;         // Sprint 13 (~300 satır)
// pub mod secure_boot;  // Sprint 13 (~350 satır)
// pub mod key;          // Sprint 13 (~250 satır)
