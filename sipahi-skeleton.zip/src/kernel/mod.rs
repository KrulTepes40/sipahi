// Katman 1: Çelik Çekirdek
// HEAP YOK · PANIC YOK · FLOAT YOK · RECURSION YOK
// 4,900 satır bütçe
// Sprint 3-7, 9-10'da implemente edilecek

// pub mod scheduler;   // Sprint 3-4
// pub mod capability;  // Sprint 9
// pub mod syscall;     // Sprint 7
// pub mod memory;      // Sprint 5-6
// pub mod policy;      // Sprint 10
